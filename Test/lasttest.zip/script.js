const main = async ()=>{
	console.log("omg this works dirname: "+ __dirname)
}
module.exports = {
	main
}