module.exports = {
function main() {
    console.log("It's working")
}
}