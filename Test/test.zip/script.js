async function main() {
	console.log("omg this works")
}
module.exports = {
	main
}