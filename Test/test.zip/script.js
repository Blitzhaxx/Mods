const main = async ()=>{
	console.log("omg this works")
}
module.exports = {
	main
}