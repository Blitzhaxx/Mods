export default function main() {
    console.log("It's working")
}